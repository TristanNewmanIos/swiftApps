//
//  ViewController.swift
//  Magic 8 Ball
//
//  Created by Tristan Newman on 11/14/18.
//  Copyright © 2018 Tristan Newman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let ballArray = ["ball1", "ball2", "ball3", "ball4", "ball5"]
    
    var ballIndex: Int = Int(arc4random_uniform(5))
    @IBOutlet weak var ballImage: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        updateBall()
    }

    @IBAction func askButtonTapped(_ sender: Any) {
        updateBall()
    }
    
    override func motionEnded(_ motion: UIEvent.EventSubtype, with event: UIEvent?) {
        updateBall()
    }
    
    func updateBall (){
        var ballIndex: Int = Int(arc4random_uniform(5))
        ballImage.image = UIImage(named: ballArray[ballIndex])
        
    }
    
}

