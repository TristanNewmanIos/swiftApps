//
//  ViewController.swift
//  Xylophone
//
//  Created by Angela Yu on 27/01/2016.
//  Copyright © 2016 London App Brewery. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, AVAudioPlayerDelegate{
    
    var audioPlayer: AVAudioPlayer!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }



    @IBAction func notePressed(_ sender: UIButton) {
        
        playSound(buttonId: sender.tag)
    }
    
    func playSound(buttonId: Int){
        
        let soundURL = Bundle.main.url(forResource: "note\(buttonId)", withExtension: "wav")
        
        do{
            // In this line we set up our audioPlayer with the content of AVAudioPlayer
            try audioPlayer = AVAudioPlayer(contentsOf: soundURL!)
        }
        catch{
            print(error)
        }
        
        audioPlayer.play()
    }
    
  

}

