//
//  ProductViewController.swift
//  Good As Old Phones
//
//  Created by Tristan Newman on 6/8/17.
//  Copyright © 2017 Create. All rights reserved.
//

import UIKit

class ProductViewController: UIViewController {

    var product: Product?
    
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var productNameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let p = product{
            
            productNameLabel.text = p.name
        
            if let i = p.productImage {
                productImageView.image = UIImage (named: i)
            }
            
        }

        
        // Do any additional setup after loading the view.
        
    
    }

    @IBAction func addToCartPressed(_ sender: Any) ->Void {
        print("Button tapped")
        
        guard let product = product, let price = product.price else {
            return
        }
        
        let alertController = UIAlertController (title: "Saved to Cart", message: "You saved item to cart with a price of \(price)", preferredStyle: .alert)
        let action = UIAlertAction (title: "OK", style: .default, handler: nil)
        alertController.addAction (action)
        
        present(alertController, animated: true, completion: nil)
    }
}
