//
//  Order.swift
//  Good As Old Phones
//
//  Created by Tristan Newman on 6/9/17.
//  Copyright © 2017 Create. All rights reserved.
//

import Foundation

class Order: NSObject, NSCoding{
    
    var order_id: Int?
    var product: Product?
    
    override init() {
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.order_id = aDecoder.decodeInteger(forKey: "order_id")
        self.product = aDecoder.decodeObject(forKey: "product") as! Product?
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(self.order_id, forKey: "order_id")
        aCoder.encode(self.product, forKey: "product")
    }
    
}
