//
//  CartTableViewController.swift
//  Good As Old Phones
//
//  Created by Tristan Newman on 6/9/17.
//  Copyright © 2017 Create. All rights reserved.
//

import UIKit

class CartTableViewController: UITableViewController {
    
    var orders: [Order]?
    

    @IBAct weak var selectOrder: UITableViewCell!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let product1 = Product()
        product1.name = "1907 Wall Phone"
        product1.productImage = "phone-fullscreen1"
        product1.cellImage = "image-cell1"
        product1.price = 19.99
        
        let order = Order()
        order.order_id = 1
        order.product = product1
        
        orders = [order, order, order, order]
        
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

  
     //Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
            
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 
 
 }
}
}
